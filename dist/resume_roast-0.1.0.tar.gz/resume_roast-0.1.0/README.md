Resume Roast
